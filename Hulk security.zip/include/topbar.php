<section class="top-bar">
            <div class="container-fluid">
               <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div style="padding-top: 9px;" class="p-t-8 text-left">
                        <ul class="list-unstyled list-inline">
                           <li class="list-inline-item">
                              Welcome to <a href="#"> www.HulkSecurity.com</a>
                            </li>
                        </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2">
                        <div style="padding-top: 9px;" class="p-t-8 text-left">
                      
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="top-right text-right">
                            <ul class="list-unstyled list-inline">
                                <li class="list-inline-item">
                                <a href="#"  data-toggle="modal" data-target="#modalsellingForm">
                                <i class="fa fa-user"></i>
                                 Start Selling
                                </a>
                                </li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-envelope"></i>
                                info@HulkSecurity.com</a></li>
                                <li class="list-inline-item"><a href="#">
                                <i class="fa fa-phone"></i>
                                +92-324-0000000</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>